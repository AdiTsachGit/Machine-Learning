import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from matplotlib import pyplot as plt
from torch.utils.data import TensorDataset, DataLoader
from tqdm import tqdm

# MS2


class MLP(nn.Module):
    """
    An MLP network which does classification.

    It should not use any convolutional layers.
    """

    def __init__(self, input_size, n_classes):
        """
        Initialize the network.

        Arguments:
            input_size (int): size of the input
            n_classes (int): number of classes to predict
        """
        super(MLP, self).__init__()

        self.fc1 = nn.Linear(input_size, 512)
        self.bn1 = nn.BatchNorm1d(512)
        self.fc2 = nn.Linear(512, 256)
        self.bn2 = nn.BatchNorm1d(256)
        self.fc3 = nn.Linear(256, 128)
        self.bn3 = nn.BatchNorm1d(128)
        self.fc4 = nn.Linear(128, n_classes)
        self.dropout = nn.Dropout(p=0.5)

    def forward(self, x):
        """
        Predict the class of a batch of samples with the model.

        Arguments:
            x (tensor): input batch of shape (N, D)
        Returns:
            preds (tensor): logits of predictions of shape (N, C)
                Reminder: logits are value pre-softmax.
        """

        # Data is flattened in main, so no need to flatten here

        x = F.relu(self.bn1(self.fc1(x)))
        x = self.dropout(x)
        x = F.relu(self.bn2(self.fc2(x)))
        x = self.dropout(x)
        x = F.relu(self.bn3(self.fc3(x)))
        x = self.dropout(x)
        preds = self.fc4(x)

        return preds


class ImprovedMLP(nn.Module):
    """
    An improved MLP network for classification.
    """

    def __init__(self, input_size, n_classes):
        """
        Initialize the network.

        Arguments:
            input_size (int): size of the input
            n_classes (int): number of classes to predict
        """
        super(ImprovedMLP, self).__init__()

        self.fc1 = nn.Linear(input_size, 1024)
        self.bn1 = nn.BatchNorm1d(1024)
        self.fc2 = nn.Linear(1024, 512)
        self.bn2 = nn.BatchNorm1d(512)
        self.fc3 = nn.Linear(512, 256)
        self.bn3 = nn.BatchNorm1d(256)
        self.fc4 = nn.Linear(256, 128)
        self.bn4 = nn.BatchNorm1d(128)
        self.fc5 = nn.Linear(128, n_classes)
        self.dropout = nn.Dropout(p=0.3)

    def forward(self, x):
        """
        Predict the class of a batch of samples with the model.

        Arguments:
            x (tensor): input batch of shape (N, D)
        Returns:
            preds (tensor): logits of predictions of shape (N, C)
                Reminder: logits are value pre-softmax.
        """

        # Data is flattened in main, so no need to flatten here

        x = F.relu(self.bn1(self.fc1(x)))
        x = self.dropout(x)
        x = F.relu(self.bn2(self.fc2(x)))
        x = self.dropout(x)
        x = F.relu(self.bn3(self.fc3(x)))
        x = self.dropout(x)
        x = F.relu(self.bn4(self.fc4(x)))
        x = self.dropout(x)
        preds = self.fc5(x)

        return preds


class CNN(nn.Module):
    """
    CNN, expects input shape (1, 28, 28).
    """

    def __init__(self, input_channels, n_classes, filters=(16, 32, 64, 128)):
        """
        Initialize the network.

        Arguments:
            input_channels (int): number of channels in the input
            n_classes (int): number of classes to predict
        """
        super(CNN, self).__init__()
        self.conv2d1 = nn.Conv2d(input_channels, filters[0], 3, 1, padding=1)
        self.bn1 = nn.BatchNorm2d(filters[0])
        self.conv2d2 = nn.Conv2d(filters[0], filters[1], 3, 1, padding=1)
        self.bn2 = nn.BatchNorm2d(filters[1])
        self.conv2d3 = nn.Conv2d(filters[1], filters[2], 3, 1, padding=1)
        self.bn3 = nn.BatchNorm2d(filters[2])
        self.conv2d4 = nn.Conv2d(filters[2], filters[3], 3, 1, padding=1)
        self.bn4 = nn.BatchNorm2d(filters[3])

        self.dropout = nn.Dropout(0.5)

        # Update the input size for fc1 based on the actual feature map size after the last pooling layer
        self.fc1 = nn.Linear(1 * 1 * filters[3], 128)  # 1x1 is the dimension after pooling layers for 28x28 input
        self.fc2 = nn.Linear(128, n_classes)

    def forward(self, x):
        """
        Predict the class of a batch of samples with the model.

        Arguments:
            x (tensor): input batch of shape (N, Ch, H, W)
        Returns:
            preds (tensor): logits of predictions of shape (N, C)
                Reminder: logits are value pre-softmax.
        """
        x = F.relu(self.bn1(self.conv2d1(x)))
        x = F.max_pool2d(x, 2)
        x = F.relu(self.bn2(self.conv2d2(x)))
        x = F.max_pool2d(x, 2)
        x = F.relu(self.bn3(self.conv2d3(x)))
        x = F.max_pool2d(x, 2)
        x = F.relu(self.bn4(self.conv2d4(x)))
        x = F.max_pool2d(x, 2)

        x = x.view(x.size(0), -1)  # flatten the tensor
        x = self.dropout(x)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        preds = self.fc2(x)
        return preds

class MyMSA(nn.Module):
    def __init__(self, d, n_heads=8):  # Increased heads
        super(MyMSA, self).__init__()
        self.d = d
        self.n_heads = n_heads

        assert d % n_heads == 0, f"Can't divide dimension {d} into {n_heads} heads"
        d_head = int(d / n_heads)
        self.d_head = d_head

        self.q_mappings = nn.ModuleList([nn.Linear(d_head, d_head) for _ in range(self.n_heads)])
        self.k_mappings = nn.ModuleList([nn.Linear(d_head, d_head) for _ in range(self.n_heads)])
        self.v_mappings = nn.ModuleList([nn.Linear(d_head, d_head) for _ in range(self.n_heads)])

        self.softmax = nn.Softmax(dim=-1)

    def forward(self, sequences):
        batch_size, seq_len, d = sequences.shape
        result = []
        for head in range(self.n_heads):
            q_mapping = self.q_mappings[head]
            k_mapping = self.k_mappings[head]
            v_mapping = self.v_mappings[head]

            seq = sequences[:, :, head * self.d_head: (head + 1) * self.d_head]

            q, k, v = q_mapping(seq), k_mapping(seq), v_mapping(seq)
            scores = (q @ k.transpose(-2, -1)) / math.sqrt(self.d_head)
            attention = self.softmax(scores)
            context = attention @ v

            result.append(context)
        return torch.cat(result, dim=-1)

class MyViTBlock(nn.Module):
    def __init__(self, hidden_d, n_heads, mlp_ratio=4, dropout_rate=0.1):
        super(MyViTBlock, self).__init__()
        self.hidden_d = hidden_d
        self.n_heads = n_heads

        self.norm1 = nn.LayerNorm(hidden_d)
        self.mhsa = MyMSA(hidden_d, n_heads)
        self.norm2 = nn.LayerNorm(hidden_d)
        self.mlp = nn.Sequential(
            nn.Linear(hidden_d, mlp_ratio * hidden_d),
            nn.GELU(),
            nn.Linear(mlp_ratio * hidden_d, hidden_d),
            nn.Dropout(dropout_rate)  # Added dropout
        )

    def forward(self, x):
        out = x + self.mhsa(self.norm1(x))
        out = out + self.mlp(self.norm2(out))
        return out

class MyViT(nn.Module):
    def __init__(self, chw, n_patches=7, n_blocks=8, hidden_d=64, n_heads=8, out_d=10):
        super(MyViT, self).__init__()

        self.chw = chw  # (C, H, W)
        self.n_patches = n_patches
        self.n_blocks = n_blocks
        self.n_heads = n_heads
        self.hidden_d = hidden_d

        # Input and patches sizes
        assert chw[1] % n_patches == 0
        assert chw[2] % n_patches == 0
        self.patch_size = (chw[1] // n_patches, chw[2] // n_patches)

        # Linear mapper
        self.input_d = int(chw[0] * self.patch_size[0] * self.patch_size[1])
        self.linear_mapper = nn.Linear(self.input_d, self.hidden_d)

        # Learnable classification token
        self.class_token = nn.Parameter(torch.rand(1, self.hidden_d))

        # Positional embedding
        self.positional_embeddings = nn.Parameter(self.get_positional_embeddings(n_patches ** 2 + 1, hidden_d))

        # Transformer blocks
        self.blocks = nn.ModuleList([MyViTBlock(hidden_d, n_heads) for _ in range(n_blocks)])

        # Classification MLP
        self.mlp = nn.Sequential(
            nn.LayerNorm(self.hidden_d),  # Added LayerNorm
            nn.Linear(self.hidden_d, out_d)
        )

    def forward(self, images):
        n, c, h, w = images.shape

        # Divide images into patches.
        patches = self.patchify(images, self.n_patches)

        # Map the vector corresponding to each patch to the hidden size dimension.
        tokens = self.linear_mapper(patches)

        # Add classification token to the tokens.
        tokens = torch.cat((self.class_token.expand(n, 1, -1), tokens), dim=1)

        # Add positional embedding.
        positional_embeddings = self.positional_embeddings.repeat(n, 1, 1)
        out = tokens + positional_embeddings

        # Transformer Blocks
        for block in self.blocks:
            out = block(out)

        # Get the classification token only.
        out = out[:, 0]

        # Map to the output distribution.
        out = self.mlp(out)

        return out

    def patchify(self, images, n_patches):
        n, c, h, w = images.shape
        assert h == w  # We assume square image

        patch_size = h // n_patches
        patches = images.unfold(2, patch_size, patch_size).unfold(3, patch_size, patch_size)
        patches = patches.permute(0, 2, 3, 1, 4, 5).reshape(n, -1, c * patch_size * patch_size)
        return patches

    def get_positional_embeddings(self, sequence_length, d):
        result = torch.ones(sequence_length, d)
        for i in range(sequence_length):
            for j in range(d):
                if j % 2 == 0:
                    result[i, j] = math.sin(i / (10000 ** (2 * j / d)))
                else:
                    result[i, j] = math.cos(i / (10000 ** (2 * j / d)))
        return result


class Trainer(object):
    """
    Trainer class for the deep networks.

    It will also serve as an interface between numpy and pytorch.
    """

    def __init__(self, model, lr, epochs, batch_size, plot=False):
        """
        Initialize the trainer object for a given model.

        Arguments:
            model (nn.Module): the model to train
            lr (float): learning rate for the optimizer
            epochs (int): number of epochs of training
            batch_size (int): number of data points in each batch
            plot (bool): whether to plot the training and validation losses
        """
        self.lr = lr
        self.epochs = epochs
        self.model = model
        self.batch_size = batch_size
        self.plot = plot

        self.criterion = nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)
        self.train_losses = []
        self.val_losses = []

    def get_train_losses(self):
        return self.train_losses

    def get_val_losses(self):
        return self.val_losses

    def train_all(self, train_dataloader, val_dataloader=None):
        """
        Fully train the model over the epochs.

        In each epoch, it calls the functions "train_one_epoch". If you want to
        add something else at each epoch, you can do it here.

        Arguments:
            train_dataloader (DataLoader): dataloader for training data
            val_dataloader (DataLoader, optional): dataloader for validation data
        """
        for ep in range(self.epochs):
            train_loss = self.train_one_epoch(train_dataloader, ep)
            self.train_losses.append(train_loss)
            if val_dataloader:
                val_loss = self.validate(val_dataloader)
                self.val_losses.append(val_loss)

        if self.plot:
            self.plot_losses()

    def train_one_epoch(self, dataloader, ep=1):
        """
        Train the model for ONE epoch.

        Should loop over the batches in the dataloader. (Recall the exercise session!)
        Don't forget to set your model to training mode, i.e., self.model.train()!

        Arguments:
            dataloader (DataLoader): dataloader for training data
        """
        self.model.train()  # set the model to training mode

        epoch_loss = 0
        progress_bar = tqdm(enumerate(dataloader), total=len(
            dataloader), desc=f"Epoch {ep+1}/{self.epochs}")

        for batch_idx, (x, y) in progress_bar:
            # Zero the gradients
            self.optimizer.zero_grad()

            # Convert x and y to appropriate tensor types
            x = x.float()  # Ensure x is a float tensor
            y = y.long()   # Ensure y is a long tensor

            # Forward pass
            logits = self.model(x)

            # Compute the loss
            loss = self.criterion(logits, y)
            epoch_loss += loss.item()

            # Backward pass
            loss.backward()

            # Optimize the parameters
            self.optimizer.step()

            # Update progress bar
            progress_bar.set_postfix(loss=epoch_loss/(batch_idx+1))

        return epoch_loss / len(dataloader)

    def validate(self, dataloader):
        """
        Validate the model on the validation set.

        Arguments:
            dataloader (DataLoader): dataloader for validation data
        """
        self.model.eval()  # set the model to evaluation mode

        val_loss = 0

        with torch.no_grad():
            for x, y in dataloader:
                x = x.float()
                y = y.long()
                logits = self.model(x)
                loss = self.criterion(logits, y)
                val_loss += loss.item()

        return val_loss / len(dataloader)

    def predict_torch(self, dataloader):
        """
        Predict the validation/test dataloader labels using the model.

        Hints:
            1. Don't forget to set your model to eval mode, i.e., self.model.eval()!
            2. You can use torch.no_grad() to turn off gradient computation,
            which can save memory and speed up computation. Simply write:
                with torch.no_grad():
                    # Write your code here.

        Arguments:
            dataloader (DataLoader): dataloader for validation/test data
        Returns:
            pred_labels (torch.tensor): predicted labels of shape (N,),
                with N the number of data points in the validation/test data.
        """
        self.model.eval()  # set the model to evaluation mode

        pred_labels = []

        with torch.no_grad():
            for batch in dataloader:
                x = batch[0]  # Unpack the batch to get the inputs
                logits = self.model(x)  # Forward pass to get logits
                # Get the predicted class labels
                _, predicted = torch.max(logits, 1)
                pred_labels.append(predicted)

        pred_labels = torch.cat(pred_labels, dim=0)

        return pred_labels

    def fit(self, training_data, training_labels, validation_data=None, validation_labels=None):
        """
        Trains the model, returns predicted labels for training data.

        This serves as an interface between numpy and pytorch.

        Arguments:
            training_data (array): training data of shape (N,D)
            training_labels (array): regression target of shape (N,)
            validation_data (array, optional): validation data of shape (N,D)
            validation_labels (array, optional): validation target of shape (N,)
        Returns:
            pred_labels (array): target of shape (N,)
        """

        # Prepare data for pytorch
        train_dataset = TensorDataset(torch.from_numpy(training_data).float(),
                                      torch.from_numpy(training_labels))
        train_dataloader = DataLoader(
            train_dataset, batch_size=self.batch_size, shuffle=True)

        if validation_data is not None and validation_labels is not None:
            val_dataset = TensorDataset(torch.from_numpy(validation_data).float(),
                                        torch.from_numpy(validation_labels))
            val_dataloader = DataLoader(
                val_dataset, batch_size=self.batch_size, shuffle=False)
        else:
            val_dataloader = None

        self.train_all(train_dataloader, val_dataloader)

        return self.predict(training_data)

    def predict(self, test_data):
        """
        Runs prediction on the test data.

        This serves as an interface between numpy and pytorch.

        Arguments:
            test_data (array): test data of shape (N,D)
        Returns:
            pred_labels (array): labels of shape (N,)
        """
        # First, prepare data for pytorch
        test_dataset = TensorDataset(torch.from_numpy(test_data).float())
        test_dataloader = DataLoader(
            test_dataset, batch_size=self.batch_size, shuffle=False)

        pred_labels = self.predict_torch(test_dataloader)

        # We return the labels after transforming them into numpy array.
        return pred_labels.cpu().numpy()

    def plot_losses(self):
        """
        Plot the training and validation losses.
        """
        epochs = range(1, self.epochs + 1)
        plt.figure(figsize=(10, 5))
        plt.plot(epochs, self.train_losses, label='Training Loss')
        if self.val_losses:
            plt.plot(epochs, self.val_losses, label='Validation Loss')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.title('Training and Validation Loss')
        plt.legend()
        plt.show()
